<html>


<head> 
    
    
    
    </head>



<body> 

<div id="login_box">  
    
    
<?php
     
    
    if (isset($_COOKIE['inloggad'])) {
        
     unset($_COOKIE['inloggad']);   
     setcookie('inloggad', null, -1);   
        
        echo "<p>Utloggad. Trevligt att du tittade förbi.</p>";
        echo "<p><a href='index.php'> klicka här </a> för att logga in</p>";
    } 
    
     else {
        
        echo "<p> du har inte loggat in ännu</p>";
        echo "<p><a href='index.php'>klicka här för att logga in</p>";
    }
        
    
    ?> 
      </div>
    
    </body>

    
</html>