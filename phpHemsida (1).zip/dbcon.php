<?php

$link = mysqli_connect("localhost", "faha0011", "Htcsmart971221", "faha0011") or die ("kunde inte koppla upp mig");
?>


    
