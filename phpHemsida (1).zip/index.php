<?php

   //personen vill logga in
if (isset($_POST['vill_logga_in']) && $_POST['vill_logga_in'] == "1") {


$_POST['vill_logga_in'] = 0;
$username = htmlentities ($_POST['txt_username']);    
$password = htmlentities ($_POST['txt_password']); 
    $enc_pass = hash("sha256", $password);
  require_once("dbcon.php");
    
    $sql ="SELECT * FROM Users WHERE db_username='$username' AND db_password='$enc_pass';";
    $result = $link->query($sql) or die ("kunde inte ställa frågan");
    
    
    
    if(mysqli_num_rows ($result) == 1) {
        
        setcookie("inloggad", $username, time()+60*60*24*365); /* Giltigt 1 år */
        header ("location:bilar.php");
    }
    
    else 
        echo "<h2> fel login </h2> <a href='index.php'> testa igen</a>";
}

else { ?>






<!DOCTYPE html>
<html>


<head>
    
    <title> inlogg </title>
      <link rel="stylesheet" type="text/css" href="stylee.css">
    </head>
                    <!-- ett formulär där man ska skriva in namn och lösenord för inloggningen.--> 
<body>
    <div id="logi _box">
  <form action="index.php" method="post">
    <p> skriv in namn och lösenord. </p>  
  <input type="text" name="txt_username" value="" placeholder="Username" /> <br />
  <input type="text" name="txt_password" placeholder="Password" /> <br  />
  <input type="submit" value="login" />
    <input type="hidden" name="vill_logga_in" value="1" />    
 
       </form>
             </div>                   
  </body>

</html>


<?php
}
?>
