<?php

$servername = "localhost";
$username = "faha0011";
$password = "Htcsmart971221";
$dbname = "faha0011";

// Create connection
$con = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$con) {
echo 'not connected to the server';                      
    
    
    //en php som skickar värdet av nya bilar till databasen som även visas upp i menysida som lista. när värdet skickas så står det "inserted" då vet man att det skickades till databasen. ifall det inte lyckades skicka så kommer det upp "not inserted". 

} 

if (!mysqli_select_db($con,'tutorial'))
{
    
    echo 'inserted';
}

$modell = $_POST['modell'];
$pris = $_POST['pris'];


$sql = "INSERT INTO volvo_v70 (Modell,Pris) VALUES ('$modell','$pris')";
if (!mysqli_query($con,$sql)) {
    
    echo 'not inserted';
}

?>

<html>
<head>
    <meta charset="utf-8">
     <link rel="stylesheet" type="text/css" href="stylee.css">
    </head>

<body>
    <br>
     <a href="bilar.php"> tillbaka till hemsidan </a>      <!-- en länk som skickar dig tillbaka till menysidan-->
    
    </body>

</html>