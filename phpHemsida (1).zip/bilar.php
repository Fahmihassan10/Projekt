
<html> 
<html> 
 <head>
   <link rel="stylesheet" type="text/css" href="bilar.css">
    <!-- en jquery script som glider ner när man klickar på den. -->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script> 
      $(document).ready(function(){
      $("#flip").click(function(){
          $("#panel").slideToggle("slow");
          });
       });
    </script>

    <style> 
</style>
 </head>
<body>
    
   
    
    <!--en div id där det står "klicka för att dra ner, och när man dragit ner så kommer det "welcome to my page"-->
   <div id="flip">Click to slide the panel down or up</div>
   <div id="panel">Welcome to my website!</div>
   
   <h2>Navigation Menu</h2>

     <!--en lista där som gör så att vi kan logga ut samt navigera till sidan "lägg till" där man lägger till modeller och priser till databasen.-->
  <ul>    
     <li><a href="index.php">logout</a></li>
     <li><a href="l%C3%A4ggtill.html">lägg till</a></li>
  </ul>    
    
    
  <p class="serif"> Här är en lista på alla mina favoritbilmärke</p> <!--här är text i font "times new roman" -->                    
  
     <!--en lista som visar mina favoritbil, en bild på bilen, kontaktuppgifter samt logotyp är med.-->
  <ol> 
     <li> <img src="ladda%20ned.jpg" alt="v60" width="200" height="200"> <!--// volvo v60-->
          <br>
          <img src="volvo.jpg" alt="v60" width="100" height="100">
         <h3>Kontakt:</h3>
         <p>Fahmi 0735574650</p>  
     </li>    
       <!--en lista som visar mina favoritbil, en bild på bilen, kontaktuppgifter samt logotyp är med.-->
     <li> <img src="volvoV70.jpg" alt="v70" width="200" height="200">
          <br>
          <img src="volvo.jpg" alt="v70" width="100" height="100"> 
          <h3>kontakt:</h3>
          <p>Dayib 0723455456</p>
     </li>
      <!--en lista som visar mina favoritbil, en bild på bilen, kontaktuppgifter samt logotyp är med.-->
      <li> <img src="volvoV40.jpg" alt="v40" width="200" height="200"> 
          <br>
          <img src="volvo.jpg" alt="v40" width="100" height="100"> 
          <h3>kontakt:</h3> 
          <p>Ibrahim 0735243677</p>
     </li>
       <!--en lista som visar mina favoritbil, en bild på bilen, kontaktuppgifter samt logotyp är med.-->
     <li> <img src="volvoXC60.jpg" alt="xc60" width="200" height="200"> 
          <br>
          <img src="volvo.jpg" alt="xc60" width="100" height="100"> 
          <h3>kontakt:</h3>
          <p>Edvin 0704590054</p>
     </li>
        <!--en lista som visar mina favoritbil, en bild på bilen, kontaktuppgifter samt logotyp är med.-->   
     <li> <img src="volvoV50.jpg" alt="v50" width="200" height="200"> 
          <br>
          <img src="volvo.jpg" alt="v50" width="100" height="100"> 
          <h3> Kontakt: </h3>
          <p>Agri 0724845900 </p>
     </li>
  </ol> 
    

    
 </body>    
</html>
    
    
    
    
       <?php
    
  if (isset($_COOKIE['inloggad'])) {
      
     
      echo "<p><a href='index.php'>Klicka här </a> för att logga ut</p>";
  } 
    else {
        
        echo "<p> du har inte loggat in ännu</p>";
         header ("location:index.php");
    }
    
    
        
$servername = "localhost";
$username = "faha0011";
$password = "Htcsmart971221";
$dbname = "faha0011";

        // Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT ID, modell, pris FROM volvo_v70";
$result = $conn->query($sql);
    

  

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "ID: " . $row["ID"]. " - bil: " . $row["modell"]. "-pris:" . $row["pris"]. "<br>";
    }
} else {
    echo "0 results";
} 
    

    
  
$conn->close();
    
    
   
?>

    ?>